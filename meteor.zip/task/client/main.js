import { Template } from 'meteor/templating';
import { ReactiveVar } from 'meteor/reactive-var';
import { Mongo } from 'meteor/mongo';


import './main.html';


Users = new Mongo.Collection('users');

Template.users.helpers({
	users: function(){
		return Users.find({}, {sort: {createdAt : -1}});
	}
});


Template.body.events({


//function to insert user

	"submit .add-user" : function(event){

		event.preventDefault();

		var name = event.target.name.value;
		var email = event.target.email.value;
		var phone = event.target.phone.value;
		var dob = event.target.dob.value;


		Users.insert({

			name: name,
			email: email,
			phone: phone,
			dob : dob,
			createdAt : new Date()

		});


		event.target.name.value='';
		event.target.email.value='';
		event.target.phone.value='';
		event.target.dob.value='';

		return false;
	},



//function to delete user

	"click .delete-user" : function(event){
		Users.remove(this._id);
		return false;
	},

	"click .edit-user" :function(event){
		var name=Meteor.users.find(Meteor.this._id, {fields: {'completedOnboarding': 1}});
		window.alert(name);
		return false;

	}
});