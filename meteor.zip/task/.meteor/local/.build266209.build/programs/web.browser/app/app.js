var require = meteorInstall({"client":{"main.html":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                          //
// client/main.html                                                                                         //
//                                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                            //
module.watch(require("./template.main.js"), {                                                               // 1
  "*": module.makeNsSetter()                                                                                // 2
});                                                                                                         // 3
                                                                                                            // 4
//////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"template.main.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                          //
// client/template.main.js                                                                                  //
//                                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                            //
                                                                                                            // 1
Template.body.addContent((function() {                                                                      // 2
  var view = this;                                                                                          // 3
  return [ HTML.Raw("<h1>Welcome to Meteor!</h1>\n\n"), HTML.DIV("\n\n", HTML.FORM({                        // 4
    class: "add-user"                                                                                       // 5
  }, "\n\n  ", HTML.TABLE("\n\n    ", HTML.TR("\n      ", HTML.TD("Name"), "\n      ", HTML.TD(HTML.INPUT({
    type: "text",                                                                                           // 7
    name: "name",                                                                                           // 8
    required: ""                                                                                            // 9
  })), "\n    "), "\n\n    ", HTML.TR("  \n      ", HTML.TD("Email"), "\n      ", HTML.TD(HTML.INPUT({      // 10
    type: "email",                                                                                          // 11
    name: "email",                                                                                          // 12
    required: ""                                                                                            // 13
  })), "\n    "), "\n\n\n    ", HTML.TR("\n      ", HTML.TD("Phone"), "\n      ", HTML.TD(HTML.INPUT({      // 14
    type: "number",                                                                                         // 15
    name: "phone",                                                                                          // 16
    required: ""                                                                                            // 17
  })), "\n    "), "\n\n\n    ", HTML.TR("\n      ", HTML.TD("DOB"), "\n      ", HTML.TD(HTML.INPUT({        // 18
    type: "date",                                                                                           // 19
    name: "dob",                                                                                            // 20
    required: ""                                                                                            // 21
  })), "\n    "), "\n\n\n\n    ", HTML.TR("\n      ", HTML.TD(), "\n      ", HTML.TD(HTML.INPUT({           // 22
    type: "submit",                                                                                         // 23
    name: "Register",                                                                                       // 24
    value: "Submit"                                                                                         // 25
  })), "\n    "), "\n\n  "), "\n\n  "), "\n"), HTML.Raw('\n\n\n<hr>\n\n<h1 align="center">Registered Users Lists</h1>\n\n  '), Spacebars.include(view.lookupTemplate("users")) ];
}));                                                                                                        // 27
Meteor.startup(Template.body.renderToDocument);                                                             // 28
                                                                                                            // 29
Template.__checkName("users");                                                                              // 30
Template["users"] = new Template("Template.users", (function() {                                            // 31
  var view = this;                                                                                          // 32
  return HTML.TABLE({                                                                                       // 33
    border: "1",                                                                                            // 34
    cellpadding: "15"                                                                                       // 35
  }, "\n\n", HTML.TR("\n  ", HTML.TH("Name"), "\n  ", HTML.TH("Email"), "\n  ", HTML.TH("Phone"), "\n  ", HTML.TH("Date Of Birth"), "\n  ", HTML.TH("Action"), "\n"), "\n\n\n\n  ", Blaze.Each(function() {
    return Spacebars.call(view.lookup("users"));                                                            // 37
  }, function() {                                                                                           // 38
    return [ "\n", HTML.TR("\n  ", HTML.TD(Blaze.View("lookup:name", function() {                           // 39
      return Spacebars.mustache(view.lookup("name"));                                                       // 40
    })), "\n  ", HTML.TD(Blaze.View("lookup:email", function() {                                            // 41
      return Spacebars.mustache(view.lookup("email"));                                                      // 42
    })), "\n  ", HTML.TD(Blaze.View("lookup:phone", function() {                                            // 43
      return Spacebars.mustache(view.lookup("phone"));                                                      // 44
    })), "\n  ", HTML.TD(Blaze.View("lookup:dob", function() {                                              // 45
      return Spacebars.mustache(view.lookup("dob"));                                                        // 46
    })), "\n  ", HTML.TD(HTML.A({                                                                           // 47
      href: "#",                                                                                            // 48
      class: "delete-user"                                                                                  // 49
    }, "Delete|"), " ", HTML.A({                                                                            // 50
      href: "#",                                                                                            // 51
      class: "edit-user"                                                                                    // 52
    }, "Edit")), "\n"), "\n  " ];                                                                           // 53
  }), "\n\n\n\n");                                                                                          // 54
}));                                                                                                        // 55
                                                                                                            // 56
//////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"main.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                          //
// client/main.js                                                                                           //
//                                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                            //
var Template = void 0;                                                                                      // 1
module.watch(require("meteor/templating"), {                                                                // 1
	Template: function (v) {                                                                                   // 1
		Template = v;                                                                                             // 1
	}                                                                                                          // 1
}, 0);                                                                                                      // 1
var ReactiveVar = void 0;                                                                                   // 1
module.watch(require("meteor/reactive-var"), {                                                              // 1
	ReactiveVar: function (v) {                                                                                // 1
		ReactiveVar = v;                                                                                          // 1
	}                                                                                                          // 1
}, 1);                                                                                                      // 1
var Mongo = void 0;                                                                                         // 1
module.watch(require("meteor/mongo"), {                                                                     // 1
	Mongo: function (v) {                                                                                      // 1
		Mongo = v;                                                                                                // 1
	}                                                                                                          // 1
}, 2);                                                                                                      // 1
module.watch(require("./main.html"));                                                                       // 1
Users = new Mongo.Collection('users');                                                                      // 9
Template.users.helpers({                                                                                    // 11
	users: function () {                                                                                       // 12
		return Users.find({}, {                                                                                   // 13
			sort: {                                                                                                  // 13
				createdAt: -1                                                                                           // 13
			}                                                                                                        // 13
		});                                                                                                       // 13
	}                                                                                                          // 14
});                                                                                                         // 11
Template.body.events({                                                                                      // 18
	//function to insert user                                                                                  // 21
	"submit .add-user": function (event) {                                                                     // 23
		event.preventDefault();                                                                                   // 25
		var name = event.target.name.value;                                                                       // 27
		var email = event.target.email.value;                                                                     // 28
		var phone = event.target.phone.value;                                                                     // 29
		var dob = event.target.dob.value;                                                                         // 30
		Users.insert({                                                                                            // 33
			name: name,                                                                                              // 35
			email: email,                                                                                            // 36
			phone: phone,                                                                                            // 37
			dob: dob,                                                                                                // 38
			createdAt: new Date()                                                                                    // 39
		});                                                                                                       // 33
		event.target.name.value = '';                                                                             // 44
		event.target.email.value = '';                                                                            // 45
		event.target.phone.value = '';                                                                            // 46
		event.target.dob.value = '';                                                                              // 47
		return false;                                                                                             // 49
	},                                                                                                         // 50
	//function to delete user                                                                                  // 54
	"click .delete-user": function (event) {                                                                   // 56
		Users.remove(this._id);                                                                                   // 57
		return false;                                                                                             // 58
	},                                                                                                         // 59
	"click .edit-user": function (event) {                                                                     // 61
		var name = Meteor.users.find(Meteor.this._id, {                                                           // 62
			fields: {                                                                                                // 62
				'completedOnboarding': 1                                                                                // 62
			}                                                                                                        // 62
		});                                                                                                       // 62
		window.alert(name);                                                                                       // 63
		return false;                                                                                             // 64
	}                                                                                                          // 66
});                                                                                                         // 18
//////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json",
    ".html",
    ".css"
  ]
});
require("./client/template.main.js");
require("./client/main.js");