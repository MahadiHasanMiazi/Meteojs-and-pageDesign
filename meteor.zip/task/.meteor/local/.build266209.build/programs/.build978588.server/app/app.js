var require = meteorInstall({"server":{"main.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////
//                                                                                //
// server/main.js                                                                 //
//                                                                                //
////////////////////////////////////////////////////////////////////////////////////
                                                                                  //
let Meteor;
module.watch(require("meteor/meteor"), {
	Meteor(v) {
		Meteor = v;
	}

}, 0);
let Mongo;
module.watch(require("meteor/mongo"), {
	Mongo(v) {
		Mongo = v;
	}

}, 1);
Meteor.startup(() => {
	const Users = new Mongo.Collection('users'); // code to run on server at startup
});
////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("./server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL21haW4uanMiXSwibmFtZXMiOlsiTWV0ZW9yIiwibW9kdWxlIiwid2F0Y2giLCJyZXF1aXJlIiwidiIsIk1vbmdvIiwic3RhcnR1cCIsIlVzZXJzIiwiQ29sbGVjdGlvbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBQSxJQUFJQSxNQUFKO0FBQVdDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0gsUUFBT0ksQ0FBUCxFQUFTO0FBQUNKLFdBQU9JLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSUMsS0FBSjtBQUFVSixPQUFPQyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNFLE9BQU1ELENBQU4sRUFBUTtBQUFDQyxVQUFNRCxDQUFOO0FBQVE7O0FBQWxCLENBQXJDLEVBQXlELENBQXpEO0FBR3BGSixPQUFPTSxPQUFQLENBQWUsTUFBTTtBQUVwQixPQUFNQyxRQUFRLElBQUlGLE1BQU1HLFVBQVYsQ0FBcUIsT0FBckIsQ0FBZCxDQUZvQixDQUluQjtBQUNELENBTEQsRSIsImZpbGUiOiIvYXBwLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5cbk1ldGVvci5zdGFydHVwKCgpID0+IHtcblx0XG5cdGNvbnN0IFVzZXJzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ3VzZXJzJyk7XG5cbiAgLy8gY29kZSB0byBydW4gb24gc2VydmVyIGF0IHN0YXJ0dXBcbn0pO1xuIl19
